package com.example.myapplication27;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityRegistration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        Button btnSignUp = findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(view -> {
            Intent inte = new Intent(ActivityRegistration.this, ActivityHome.class);
            startActivity(inte);
            Toast.makeText(ActivityRegistration.this, "The account has been successfully registered", Toast.LENGTH_SHORT).show();
        });


    }
}