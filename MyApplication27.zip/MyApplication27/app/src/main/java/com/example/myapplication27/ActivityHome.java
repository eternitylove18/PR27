package com.example.myapplication27;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityHome extends AppCompatActivity {

    TextView CreateAccount;
    Button btnSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        btnSignIn = (Button) findViewById(R.id.btnSignIn);
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(ActivityHome.this, ActivityBase.class);
                startActivity(intent1);
                Toast.makeText(ActivityHome.this, "Authorization was successful", Toast.LENGTH_SHORT).show();
            }
        });


        CreateAccount=(TextView) findViewById(R.id.CreateAccount);
        CreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ActivityHome.this, ActivityRegistration.class);
                startActivity(i);
                Toast.makeText(ActivityHome.this, "You click Create Account", Toast.LENGTH_SHORT).show();
            }
        });
    }
}